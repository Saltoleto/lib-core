# Sequential API Client

Uma biblioteca Java 21 para realizar chamadas sequenciais a APIs externas, utilizando threads virtuais e seguindo os princípios SOLID.

## Características

- ✅ **Java 21**: Utiliza as mais recentes funcionalidades do Java, incluindo threads virtuais
- ✅ **Threads Virtuais**: Performance otimizada para operações I/O intensivas
- ✅ **Princípios SOLID**: Código bem estruturado e facilmente extensível
- ✅ **Chamadas Sequenciais**: Suporte nativo para APIs que dependem de respostas anteriores
- ✅ **Sem Spring Boot**: Biblioteca leve sem dependências pesadas
- ✅ **Assíncrono**: Baseado em CompletableFuture para operações não-bloqueantes

## Instalação

### Maven

```xml
<dependency>
    <groupId>com.sequentialapi</groupId>
    <artifactId>sequential-api-client</artifactId>
    <version>1.0.0</version>
</dependency>
```

### Gradle

```gradle
implementation 'com.sequentialapi:sequential-api-client:1.0.0'
```

## Uso Básico

### Exemplo Simples

```java
import com.sequentialapi.SequentialApiClientBuilder;
import com.sequentialapi.model.ApiRequest;
import com.sequentialapi.model.ApiResponse;
import com.sequentialapi.service.SequentialApiService;

// Criar o serviço
SequentialApiService apiService = SequentialApiClientBuilder.create().build();

// Primeira chamada
ApiRequest initialRequest = new ApiRequest(
    "https://api.exemplo.com/usuarios/1", 
    "GET", 
    null, 
    null
);

// Definir próximas chamadas baseadas na resposta anterior
Function<ApiResponse<?>, ApiRequest> segundaChamada = response -> {
    Map<String, Object> userData = (Map<String, Object>) response.getBody();
    String userId = userData.get("id").toString();
    
    return new ApiRequest(
        "https://api.exemplo.com/perfil/" + userId,
        "GET",
        null,
        null
    );
};

List<Function<ApiResponse<?>, ApiRequest>> builders = Arrays.asList(segundaChamada);

// Executar chamadas sequenciais
CompletableFuture<ApiResponse<Object>> resultado = apiService.executeSequentialCalls(
    initialRequest,
    builders,
    Object.class
);

ApiResponse<Object> resposta = resultado.get();
```

### Exemplo com 4 Chamadas Sequenciais

```java
public class ExemploCompleto {
    public static void main(String[] args) {
        SequentialApiService apiService = SequentialApiClientBuilder.create().build();

        // 1ª Chamada: Buscar usuário
        ApiRequest primeiraRequisicao = new ApiRequest(
            "https://api.exemplo.com/usuarios/1", "GET", null, null
        );

        // 2ª Chamada: Buscar dados baseados no usuário
        Function<ApiResponse<?>, ApiRequest> segundaChamada = userResponse -> {
            String userId = extrairUserId(userResponse);
            return new ApiRequest(
                "https://api.exemplo.com/dados/" + userId, "GET", null, null
            );
        };

        // 3ª Chamada: Processar dados
        Function<ApiResponse<?>, ApiRequest> terceiraChamada = dataResponse -> {
            String dataId = extrairDataId(dataResponse);
            return new ApiRequest(
                "https://api.exemplo.com/processar/" + dataId, "POST", null, 
                Map.of("action", "process")
            );
        };

        // 4ª Chamada: Gerar relatório
        Function<ApiResponse<?>, ApiRequest> quartaChamada = processResponse -> {
            String processId = extrairProcessId(processResponse);
            return new ApiRequest(
                "https://api.exemplo.com/relatorio/" + processId, "GET", null, null
            );
        };

        List<Function<ApiResponse<?>, ApiRequest>> builders = Arrays.asList(
            segundaChamada, terceiraChamada, quartaChamada
        );

        // Executar todas as 4 chamadas sequencialmente
        apiService.executeSequentialCalls(primeiraRequisicao, builders, Object.class)
                  .thenAccept(resposta -> {
                      if (resposta.isSuccess()) {
                          System.out.println("Sucesso: " + resposta.getBody());
                      } else {
                          System.err.println("Erro: " + resposta.getStatusCode());
                      }
                  });
    }
}
```

## Arquitetura

A biblioteca segue os princípios SOLID:

### Single Responsibility Principle (SRP)
- `ApiClient`: Responsável apenas por chamadas HTTP
- `SequentialApiService`: Responsável apenas pela orquestração sequencial
- `ApiRequest`/`ApiResponse`: Responsáveis apenas por representar dados

### Open/Closed Principle (OCP)
- Interfaces permitem extensão sem modificação do código existente
- `ResponseProcessor` permite diferentes tipos de processamento

### Liskov Substitution Principle (LSP)
- Implementações podem ser substituídas sem quebrar o código cliente

### Interface Segregation Principle (ISP)
- Interfaces pequenas e específicas para cada responsabilidade

### Dependency Inversion Principle (DIP)
- Dependências são injetadas através de interfaces, não implementações concretas

## Threads Virtuais

A biblioteca utiliza as threads virtuais do Java 21 para:

- **Melhor Performance**: Milhares de threads virtuais com baixo overhead
- **Escalabilidade**: Suporte a muitas operações I/O simultâneas
- **Simplicidade**: Código síncrono com performance assíncrona

```java
// Threads virtuais são usadas automaticamente
Executor virtualThreadExecutor = Executors.newVirtualThreadPerTaskExecutor();
```

## Tratamento de Erros

```java
try {
    ApiResponse<String> resposta = apiService.executeSequentialCalls(...)
                                           .get();
    
    if (!resposta.isSuccess()) {
        System.err.println("Erro HTTP: " + resposta.getStatusCode());
    }
    
} catch (ApiException e) {
    System.err.println("Erro na API: " + e.getMessage());
    System.err.println("Status: " + e.getStatusCode());
    System.err.println("Resposta: " + e.getResponseBody());
}
```

## Configuração Customizada

```java
// Cliente HTTP customizado
ApiClient clienteCustomizado = new MeuClienteCustomizado();

SequentialApiService servico = SequentialApiClientBuilder.create()
    .withApiClient(clienteCustomizado)
    .build();
```

## Requisitos

- Java 21 ou superior
- Maven 3.6+ ou Gradle 7+

## Dependências

- Jackson (para processamento JSON)
- SLF4J (para logging)
- JUnit 5 (para testes)

## Licença

MIT License - veja o arquivo LICENSE para detalhes.

## Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## Suporte

Para dúvidas ou problemas, abra uma issue no GitHub ou entre em contato através de [email@exemplo.com].

