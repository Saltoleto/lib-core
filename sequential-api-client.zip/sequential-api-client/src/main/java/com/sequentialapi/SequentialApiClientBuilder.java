package com.sequentialapi;

import com.sequentialapi.client.ApiClient;
import com.sequentialapi.client.JavaHttpClient;
import com.sequentialapi.service.SequentialApiService;
import com.sequentialapi.service.SequentialApiServiceImpl;

/**
 * Builder para facilitar a criação e configuração do cliente de APIs sequenciais.
 * Segue o padrão Builder para uma API fluente e fácil de usar.
 */
public class SequentialApiClientBuilder {
    
    private ApiClient apiClient;

    public SequentialApiClientBuilder() {
        // Configuração padrão
        this.apiClient = new JavaHttpClient();
    }

    /**
     * Define um cliente HTTP customizado.
     * 
     * @param apiClient O cliente HTTP a ser usado
     * @return Este builder para encadeamento
     */
    public SequentialApiClientBuilder withApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
        return this;
    }

    /**
     * Constrói o serviço de APIs sequenciais.
     * 
     * @return Uma instância configurada do SequentialApiService
     */
    public SequentialApiService build() {
        return new SequentialApiServiceImpl(apiClient);
    }

    /**
     * Método estático para criar um builder com configuração padrão.
     * 
     * @return Um novo builder
     */
    public static SequentialApiClientBuilder create() {
        return new SequentialApiClientBuilder();
    }
}

