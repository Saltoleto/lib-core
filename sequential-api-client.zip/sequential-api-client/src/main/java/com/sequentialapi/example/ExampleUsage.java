package com.sequentialapi.example;

import com.sequentialapi.SequentialApiClientBuilder;
import com.sequentialapi.model.ApiRequest;
import com.sequentialapi.model.ApiResponse;
import com.sequentialapi.service.SequentialApiService;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

/**
 * Exemplo de uso da biblioteca Sequential API Client.
 * Demonstra como realizar 4 chamadas sequenciais onde cada uma depende da anterior.
 */
public class ExampleUsage {

    public static void main(String[] args) {
        // Criar o serviço usando o builder
        SequentialApiService apiService = SequentialApiClientBuilder.create().build();

        // Exemplo: Buscar dados de usuário -> Buscar perfil -> Buscar configurações -> Buscar relatório
        executeSequentialApiExample(apiService);
    }

    private static void executeSequentialApiExample(SequentialApiService apiService) {
        // 1ª Chamada: Buscar dados básicos do usuário
        ApiRequest initialRequest = new ApiRequest(
            "https://jsonplaceholder.typicode.com/users/1", 
            "GET", 
            null, 
            null
        );

        // 2ª Chamada: Buscar posts do usuário baseado no ID retornado
        Function<ApiResponse<?>, ApiRequest> getPostsBuilder = userResponse -> {
            @SuppressWarnings("unchecked")
            Map<String, Object> userData = (Map<String, Object>) userResponse.getBody();
            String userId = userData.get("id").toString();
            
            return new ApiRequest(
                "https://jsonplaceholder.typicode.com/posts?userId=" + userId,
                "GET",
                null,
                null
            );
        };

        // 3ª Chamada: Buscar comentários do primeiro post
        Function<ApiResponse<?>, ApiRequest> getCommentsBuilder = postsResponse -> {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> posts = (List<Map<String, Object>>) postsResponse.getBody();
            if (!posts.isEmpty()) {
                String postId = posts.get(0).get("id").toString();
                return new ApiRequest(
                    "https://jsonplaceholder.typicode.com/comments?postId=" + postId,
                    "GET",
                    null,
                    null
                );
            }
            throw new RuntimeException("Nenhum post encontrado");
        };

        // 4ª Chamada: Buscar álbuns do usuário (usando dados da primeira chamada armazenados)
        Function<ApiResponse<?>, ApiRequest> getAlbumsBuilder = commentsResponse -> {
            // Em um cenário real, você poderia armazenar dados de chamadas anteriores
            // Para este exemplo, vamos usar um ID fixo
            return new ApiRequest(
                "https://jsonplaceholder.typicode.com/albums?userId=1",
                "GET",
                null,
                null
            );
        };

        List<Function<ApiResponse<?>, ApiRequest>> requestBuilders = Arrays.asList(
            getPostsBuilder,
            getCommentsBuilder,
            getAlbumsBuilder
        );

        // Executar as chamadas sequenciais
        System.out.println("Iniciando execução sequencial de 4 APIs...");
        
        CompletableFuture<ApiResponse<Object>> futureResult = apiService.executeSequentialCalls(
            initialRequest,
            requestBuilders,
            Object.class
        );

        try {
            ApiResponse<Object> finalResponse = futureResult.get();
            
            if (finalResponse.isSuccess()) {
                System.out.println("✅ Execução sequencial concluída com sucesso!");
                System.out.println("Status final: " + finalResponse.getStatusCode());
                System.out.println("Resultado final: " + finalResponse.getBody());
            } else {
                System.err.println("❌ Execução falhou com status: " + finalResponse.getStatusCode());
            }
            
        } catch (Exception e) {
            System.err.println("❌ Erro durante a execução: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

