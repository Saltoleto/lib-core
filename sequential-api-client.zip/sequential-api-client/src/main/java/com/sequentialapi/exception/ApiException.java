package com.sequentialapi.exception;

/**
 * Exceção base para erros relacionados a chamadas de API.
 */
public class ApiException extends RuntimeException {
    private final int statusCode;
    private final String responseBody;

    public ApiException(String message) {
        super(message);
        this.statusCode = -1;
        this.responseBody = null;
    }

    public ApiException(String message, Throwable cause) {
        super(message, cause);
        this.statusCode = -1;
        this.responseBody = null;
    }

    public ApiException(String message, int statusCode, String responseBody) {
        super(message);
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

    public ApiException(String message, int statusCode, String responseBody, Throwable cause) {
        super(message, cause);
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public String getResponseBody() {
        return responseBody;
    }

    @Override
    public String toString() {
        return "ApiException{" +
               "message='" + getMessage() + '\'' +
               ", statusCode=" + statusCode +
               ", responseBody='" + responseBody + '\'' +
               '}';
    }
}

