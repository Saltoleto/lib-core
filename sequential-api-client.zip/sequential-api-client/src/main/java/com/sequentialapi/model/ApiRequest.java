package com.sequentialapi.model;

import java.util.Map;
import java.util.Objects;

/**
 * Representa uma requisição para uma API externa.
 */
public class ApiRequest {
    private final String url;
    private final String method;
    private final Map<String, String> headers;
    private final Object body;

    public ApiRequest(String url, String method, Map<String, String> headers, Object body) {
        this.url = Objects.requireNonNull(url, "URL não pode ser nula");
        this.method = Objects.requireNonNull(method, "Método HTTP não pode ser nulo");
        this.headers = headers;
        this.body = body;
    }

    public String getUrl() {
        return url;
    }

    public String getMethod() {
        return method;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public Object getBody() {
        return body;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ApiRequest that = (ApiRequest) o;
        return Objects.equals(url, that.url) &&
               Objects.equals(method, that.method) &&
               Objects.equals(headers, that.headers) &&
               Objects.equals(body, that.body);
    }

    @Override
    public int hashCode() {
        return Objects.hash(url, method, headers, body);
    }

    @Override
    public String toString() {
        return "ApiRequest{" +
               "url='" + url + '\'' +
               ", method='" + method + '\'' +
               ", headers=" + headers +
               ", body=" + body +
               '}';
    }
}

