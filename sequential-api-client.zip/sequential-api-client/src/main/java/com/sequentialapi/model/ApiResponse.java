package com.sequentialapi.model;

import java.util.Map;
import java.util.Objects;

/**
 * Representa uma resposta de uma API externa.
 */
public class ApiResponse<T> {
    private final int statusCode;
    private final Map<String, String> headers;
    private final T body;
    private final boolean success;

    public ApiResponse(int statusCode, Map<String, String> headers, T body) {
        this.statusCode = statusCode;
        this.headers = headers;
        this.body = body;
        this.success = statusCode >= 200 && statusCode < 300;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public T getBody() {
        return body;
    }

    public boolean isSuccess() {
        return success;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ApiResponse<?> that = (ApiResponse<?>) o;
        return statusCode == that.statusCode &&
               success == that.success &&
               Objects.equals(headers, that.headers) &&
               Objects.equals(body, that.body);
    }

    @Override
    public int hashCode() {
        return Objects.hash(statusCode, headers, body, success);
    }

    @Override
    public String toString() {
        return "ApiResponse{" +
               "statusCode=" + statusCode +
               ", headers=" + headers +
               ", body=" + body +
               ", success=" + success +
               '}';
    }
}

