package com.sequentialapi.service;

import com.sequentialapi.client.ApiClient;
import com.sequentialapi.exception.ApiException;
import com.sequentialapi.model.ApiRequest;
import com.sequentialapi.model.ApiResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SequentialApiServiceImplTest {

    @Mock
    private ApiClient mockApiClient;

    private SequentialApiService sequentialApiService;

    @BeforeEach
    void setUp() {
        sequentialApiService = new SequentialApiServiceImpl(mockApiClient);
    }

    @Test
    void testExecuteSequentialCalls_Success() {
        // Mocking responses
        Map<String, Object> response1Data = Map.of("id", "123", "data", "value1");
        Map<String, Object> response2Data = Map.of("status", "success", "info", "data2");
        String response3Data = "{\"result\":\"final\"}";

        ApiResponse<Object> mockResponse1 = new ApiResponse<>(200, new HashMap<>(), response1Data);
        ApiResponse<Object> mockResponse2 = new ApiResponse<>(200, new HashMap<>(), response2Data);
        ApiResponse<String> mockResponse3 = new ApiResponse<>(200, new HashMap<>(), response3Data);

        when(mockApiClient.get(eq("http://api.example.com/step1"), eq(Object.class)))
                .thenReturn(CompletableFuture.completedFuture(mockResponse1));
        when(mockApiClient.get(eq("http://api.example.com/step2?id=123"), eq(Object.class)))
                .thenReturn(CompletableFuture.completedFuture(mockResponse2));
        when(mockApiClient.get(eq("http://api.example.com/step3?status=success"), eq(String.class)))
                .thenReturn(CompletableFuture.completedFuture(mockResponse3));

        // Initial request
        ApiRequest initialRequest = new ApiRequest("http://api.example.com/step1", "GET", null, null);

        // Request builders
        Function<ApiResponse<?>, ApiRequest> step2Builder = prevResponse -> {
            @SuppressWarnings("unchecked")
            Map<String, Object> data = (Map<String, Object>) prevResponse.getBody();
            String id = (String) data.get("id");
            return new ApiRequest("http://api.example.com/step2?id=" + id, "GET", null, null);
        };

        Function<ApiResponse<?>, ApiRequest> step3Builder = prevResponse -> {
            @SuppressWarnings("unchecked")
            Map<String, Object> data = (Map<String, Object>) prevResponse.getBody();
            String status = (String) data.get("status");
            return new ApiRequest("http://api.example.com/step3?status=" + status, "GET", null, null);
        };

        List<Function<ApiResponse<?>, ApiRequest>> requestBuilders = Arrays.asList(step2Builder, step3Builder);

        // Execute sequential calls
        CompletableFuture<ApiResponse<String>> futureResult = sequentialApiService.executeSequentialCalls(
                initialRequest, requestBuilders, String.class);

        ApiResponse<String> finalResponse = futureResult.join();

        assertNotNull(finalResponse);
        assertTrue(finalResponse.isSuccess());
        assertEquals(200, finalResponse.getStatusCode());
        assertEquals(response3Data, finalResponse.getBody());
    }

    @Test
    void testExecuteSequentialCalls_InitialCallFailure() {
        ApiResponse<Object> mockResponse1 = new ApiResponse<>(500, new HashMap<>(), "Internal Server Error");

        when(mockApiClient.get(eq("http://api.example.com/step1"), eq(Object.class)))
                .thenReturn(CompletableFuture.completedFuture(mockResponse1));

        ApiRequest initialRequest = new ApiRequest("http://api.example.com/step1", "GET", null, null);
        List<Function<ApiResponse<?>, ApiRequest>> requestBuilders = Collections.emptyList();

        CompletableFuture<ApiResponse<String>> futureResult = sequentialApiService.executeSequentialCalls(
                initialRequest, requestBuilders, String.class);

        CompletionException thrown = assertThrows(CompletionException.class, futureResult::join);
        assertTrue(thrown.getCause() instanceof ApiException);
        ApiException apiException = (ApiException) thrown.getCause();
        assertEquals(500, apiException.getStatusCode());
        assertEquals("Primeira chamada falhou", apiException.getMessage());
    }

    @Test
    void testExecuteSequentialCalls_IntermediateCallFailure() {
        Map<String, Object> response1Data = Map.of("id", "123");
        ApiResponse<Object> mockResponse1 = new ApiResponse<>(200, new HashMap<>(), response1Data);
        ApiResponse<Object> mockResponse2 = new ApiResponse<>(404, new HashMap<>(), "Not Found");

        when(mockApiClient.get(eq("http://api.example.com/step1"), eq(Object.class)))
                .thenReturn(CompletableFuture.completedFuture(mockResponse1));
        when(mockApiClient.get(eq("http://api.example.com/step2?id=123"), eq(Object.class)))
                .thenReturn(CompletableFuture.completedFuture(mockResponse2));

        ApiRequest initialRequest = new ApiRequest("http://api.example.com/step1", "GET", null, null);
        Function<ApiResponse<?>, ApiRequest> step2Builder = prevResponse -> {
            @SuppressWarnings("unchecked")
            Map<String, Object> data = (Map<String, Object>) prevResponse.getBody();
            String id = (String) data.get("id");
            return new ApiRequest("http://api.example.com/step2?id=" + id, "GET", null, null);
        };
        List<Function<ApiResponse<?>, ApiRequest>> requestBuilders = Arrays.asList(step2Builder);

        CompletableFuture<ApiResponse<String>> futureResult = sequentialApiService.executeSequentialCalls(
                initialRequest, requestBuilders, String.class);

        CompletionException thrown = assertThrows(CompletionException.class, futureResult::join);
        assertTrue(thrown.getCause() instanceof ApiException);
        ApiException apiException = (ApiException) thrown.getCause();
        assertEquals(404, apiException.getStatusCode());
        assertEquals("Chamada intermediária falhou", apiException.getMessage());
    }
}

